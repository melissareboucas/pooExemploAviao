public class InvalidCityException extends Exception {
  
}