public class WrongPasswordException extends Exception {
  
}