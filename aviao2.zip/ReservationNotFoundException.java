public class ReservationNotFoundException extends RuntimeException {
  
}