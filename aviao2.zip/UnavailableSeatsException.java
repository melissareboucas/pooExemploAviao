public class UnavailableSeatsException extends RuntimeException {
  
}