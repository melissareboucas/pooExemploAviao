public class FlightNotFoundException extends RuntimeException {
  
}