public class FlightAlreadyExistsException extends Exception {
  
}