public class NoAvailableSeatsException extends Exception {
  
}