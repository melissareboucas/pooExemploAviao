public class UnavailableNormalSeatsException extends RuntimeException {
  
}