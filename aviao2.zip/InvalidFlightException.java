public class InvalidFlightException extends Exception {
  
}